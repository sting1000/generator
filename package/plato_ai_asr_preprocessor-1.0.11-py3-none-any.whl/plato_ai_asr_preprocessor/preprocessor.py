"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
from plato_ai_asr_preprocessor.transcription_utils import transcription_processor
from plato_ai_asr_preprocessor.transcription_utils.constants import ALLOWED_LANGUAGES
import os
import json


class Preprocessor:

    def __init__(self, use_case, cleaner_config=None, abbreviation_config=None):

        with open(os.path.join(os.path.dirname(__file__), 'transcription_utils/cleaner_configurations/cleaners.json'),
                  'r', encoding='utf-8') as default_cleaner_json:
            cleaner_configs = json.load(default_cleaner_json)

        if cleaner_config:
            cmd_line_cleaner_json = open(cleaner_config, 'r', encoding='utf-8')
            cleaner_configs = json.load(cmd_line_cleaner_json)

        if use_case in cleaner_configs.keys():
            cleaner_config = cleaner_configs[use_case]
        else:
            cleaner_types = ' '.join(cleaner_configs.keys())
            raise KeyError('Cleaner type not found, should be one of ' + cleaner_types)

        try:
            self.process_annotations = cleaner_config['process-annotations']
            self.process_hashtags = cleaner_config['process-hashtags']
            self.process_hesitations = cleaner_config['process-hesitations']
            self.acronym_method = cleaner_config['acronym-method']
            self.remove_chars = cleaner_config['remove-chars']
        except KeyError:
            raise KeyError('Cleaner configuration incomplete, have you defined all of process-annotations ' +
                           'process-hashtags process-hesitations acronym-method remove-chars')

        self.configuration = {
                                'process-annotations': self.process_annotations,
                                'process-hashtags': self.process_hashtags,
                                'process-hesitations': self.process_hesitations,
                                'acronym-method': self.acronym_method,
                                'remove-chars': self.remove_chars
                             }

        with open(os.path.join(os.path.dirname(__file__), 'transcription_utils/abbreviations/abbreviations.json'), 'r',
                  encoding='utf-8') as abbreviation_file:
            self.abbreviation_map = json.load(abbreviation_file)

        if abbreviation_config:
            file_abbrev = open(abbreviation_config, 'r', encoding='utf-8')
            self.abbreviation_map = json.load(file_abbrev)

    def process(self, text: str, language: str) -> ():
        """
        Clean up text and turn everything into words, like dates, times and numbers.
        Remove punctuation and lowercase.
        """
        if language in ALLOWED_LANGUAGES:
            text = transcription_processor.apply_cleanup(text, language, self.configuration, self.abbreviation_map)
            return text
        else:
            return 'unknown language', []

    def __repr__(self):
        return \
            f'process-annotations:{self.process_annotations}' \
            f'\nprocess-hashtags:{self.process_hashtags}' \
            f'\nprocess-hesitations:{self.process_hesitations}' \
            f'\nacronym-method:{self.acronym_method}' \
            f'\nremove-chars:{self.remove_chars}'
