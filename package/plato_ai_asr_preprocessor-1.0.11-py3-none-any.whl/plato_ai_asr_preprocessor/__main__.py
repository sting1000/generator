"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
import argparse
import os

from plato_ai_asr_preprocessor.preprocessor import Preprocessor


def parse_arguments():
    """Parses the arguments.

    Possible command line args:
        --training-text: the training text to validate
        --cleaned-text: will contain only valid training text
        --language: one of de, en, it, fr
        --use-case: one of kaldi-g2p, kaldi-am, kaldi-lm, tv, azure
    """
    parser = argparse.ArgumentParser(description='Clean the training text and makes sue it respects the guidelines.')
    parser.add_argument('--training-text', required=True, help='The training text to validate')
    parser.add_argument('--cleaned-text', required=True, help='Will contain only cleaned training text')
    parser.add_argument('--language', required=True, help='Language of the input text')
    parser.add_argument('--use-case', required=True, choices=['kaldi-g2p', 'kaldi-am', 'kaldi-lm', 'tv', 'azure-am',
                                                              'azure-lm', 'my-cleaner', 'my-cleaner-am'],
                        help='Indicator which cleaning rules need to apply')
    parser.add_argument('--cleaner-config', required=False, help='Overriding json file with cleaner configuration')
    parser.add_argument('--abbreviation-config', required=False, help='Overriding json file with abbreviations')

    return parser.parse_args()


args = parse_arguments()
print(type(args))
print(args)

use_case = args.use_case
if 'azure' in use_case:
    use_case = 'azure'
if 'my-cleaner' in use_case:
    use_case = 'my-cleaner'

preprocessor = Preprocessor(use_case, args.cleaner_config, args.abbreviation_config)

with open(os.path.join(os.path.dirname(__file__), args.training_text), 'r', encoding='utf-8') as file_in, \
        open(os.path.join(os.path.dirname(__file__), args.cleaned_text), 'w', encoding='utf-8') as file_out:

    for line in file_in.readlines():
        line = line.strip()
        output = ''
        if args.use_case == 'kaldi-g2p' or args.use_case == 'kaldi-lm' or args.use_case == 'azure-lm' \
           or args.use_case == 'my-cleaner':
            check_result = preprocessor.process(line, args.language)
            output = check_result[0]
            if output == '':
                continue
        elif args.use_case == 'kaldi-am' or args.use_case == 'azure-am' or args.use_case == 'my-cleaner-am':
            uid, transcription = line.split('\t')
            check_result = preprocessor.process(transcription, args.language)
            # if the cleaning process results in an empty string remove the entry altogether
            if check_result[0] == '':
                continue
            output = '%s\t%s' % (uid, check_result[0])

        file_out.write(output + '\n')
