"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""

ALLOWED_LANGUAGES = ['de', 'en', 'fr', 'it']

ALLOWED_CHARLIST = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZäöüëÄÖÜËéÉàèÀÈâêîôûÂÊÎÔÛïÏçÇ'
ALLOWED_CHARSET = set(list(ALLOWED_CHARLIST + '[]#-\' '))

UNKNOWN_MONTH = 'unknown month'

UNKNOWN_LANGUAGE = 'unknown language'

# see https://en.wikipedia.org/wiki/Dash for info on these longer types of hyphens that should also be removed
en_dash = chr(0x2013)
em_dash = chr(0x2014)
horizontal_bar = chr(0x2015)

# these punctuation symbols are those not used for any special purpose in ASR processing
UNUSED_PUNCTUATION_MAP = {
    '"': ' ',  # double quote
    '|': ' ',  # pipe symbol
    '?': ' ',  # question mark'
    '`': ' ',  # backtick
    ';': ' ',  # semi colon
    ':': ' ',  # colon
    '.': ' ',  # period or full stop
    ',': ' ',  # comma
    '<': ' ',  # left angle bracket
    '>': ' ',  # right angle bracket
    '(': ' ',  # left bracket
    ')': ' ',  # right bracket
    '{': ' ',  # left curly bracket
    '}': ' ',  # right curly bracket
    '!': ' ',  # exclamation
    '“': ' ',  # german top quote
    '„': ' ',  # german bottom quote
    '«': ' ',  # double angle bracket left
    '»': ' ',  # double angle bracket right
    '@': ' ',  # at symbol
    '’': ' ',  # funny apostrophe
    en_dash: ' ',
    em_dash: ' ',
    horizontal_bar: ' ',
    '…': ' '  # triple dot symbol
}

# these punctuation symbols are those used for a special purpose in ASR processing
SPECIAL_PUNCTUATION = {
    '-': ' ',  # hyphen
    '#': ' ',  # hash
    '[': ' ',  # left square bracket
    ']': ' '  # right square bracket
}

PUNCTUATION_MAP = {**UNUSED_PUNCTUATION_MAP, **SPECIAL_PUNCTUATION}
