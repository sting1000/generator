"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
from num2words import num2words
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_decimal_number
from plato_ai_asr_preprocessor.transcription_utils.transcriber import Transcriber
from plato_ai_asr_preprocessor.transcription_utils.env import env


class GermanTranscriber (Transcriber):

    CENTURY_WORD = ' hundert '

    try:
        NUMBER_LENGTH_THRESHOLD = int(env.GERMAN_NUMBER_LENGTH_THRESHOLD)
    except ValueError:
        raise ValueError(f'Cannot convert GERMAN_NUMBER_LENGTH_THRESHOLD '
                         f'env parameter with value {env.GERMAN_NUMBER_LENGTH_THRESHOLD} to integer')

    HOUR_WORD = ' uhr '
    HOUR_TO_MINUTE_CONNECTOR = ''

    DECIMAL_SEPARATOR = ' komma '
    DECIMAL_REGEX = regexp_decimal_number

    CURRENCY_WORDS = {
        '£': (' pfund ', ' pfund ', ' pence '),
        '€': (' euro ', ' euro ', ' cent '),
        '$': (' dollar ', ' dollar ', ' cent ')
    }

    MONTH = {1: 'januar',
             2: 'februar',
             3: 'märz',
             4: 'april',
             5: 'mai',
             6: 'juni',
             7: 'juli',
             8: 'august',
             9: 'september',
             10: 'oktober',
             11: 'november',
             12: 'dezember'
             }

    SPOKEN_SYMBOLS_MAP = {
            '+': ' plus ',
            '%': ' prozent ',
            '&': ' und '
    }

    @classmethod
    def replace_num_with_words(cls, input: str) -> str:
        if cls.is_text_length_above_threshold(input):
            return cls.read_out_number_string(input)
        text = num2words(int(input), lang='de')
        text = text.replace('ß', 'ss')
        return text

    @staticmethod
    def read_out_number_string(input: str) -> str:
        text = ' '.join([num2words(int(s), lang='de') for s in input])
        text = text.replace('ß', 'ss')
        return text

    @classmethod
    def replace_num_with_ordinal_words(cls, input: str) -> str:
        if cls.is_text_length_above_threshold(input):
            return cls.read_out_number_string(input)
        text = num2words(int(input), ordinal=True, lang='de')
        text = text.replace('ß', 'ss')
        return text

    @classmethod
    def say_date(cls, day: str, month: str, year: str = None) -> str:
        if year and len(year) == 4:
            century = year[:2]
            year = year[2:]
            date_string = cls.replace_num_with_ordinal_words(day) + ' ' + month + ' ' \
                + cls.replace_num_with_words(century) + cls.CENTURY_WORD \
                + cls.replace_num_with_words(year)
        elif year and len(year) == 2:
            date_string = cls.replace_num_with_ordinal_words(day) + ' ' + month + ' ' \
                + cls.replace_num_with_words(year)
        else:
            date_string = cls.replace_num_with_ordinal_words(day) + ' ' + month + ' '
        return date_string

    @classmethod
    def say_money(cls, whole: str, part: str, currency_symbol: str) -> str:
        currency_word = cls.CURRENCY_WORDS[currency_symbol]
        whole_words = cls.replace_num_with_words(whole)
        if whole_words == 'eins':
            whole_words = 'ein'
        if int(whole) == 1:
            currency = currency_word[0]
        else:
            currency = currency_word[1]

        if part and len(part) > 0:
            if int(whole) == 0:
                money_string = cls.replace_num_with_words(part) + currency_word[2]
            else:
                money_string = whole_words + currency + cls.replace_num_with_words(part) + currency_word[2]
        else:
            money_string = whole_words + currency
        return money_string

    @classmethod
    def say_time(cls, hour: str, minute: str) -> str:
        if int(minute) == 0:
            time_string = cls.replace_num_with_words(hour) + cls.HOUR_WORD
        else:
            time_string = cls.replace_num_with_words(hour) + cls.HOUR_WORD + cls.HOUR_TO_MINUTE_CONNECTOR \
                          + cls.replace_num_with_words(minute)
        return time_string

    @classmethod
    def is_text_length_above_threshold(cls, text: str):
        return len(text) > cls.NUMBER_LENGTH_THRESHOLD

    @classmethod
    def get_threshold(cls):
        return cls.NUMBER_LENGTH_THRESHOLD

    @classmethod
    def set_threshold(cls, new_value: int):
        cls.NUMBER_LENGTH_THRESHOLD = new_value
