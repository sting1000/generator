"""
(c) Copyright 2018 Swisscom AG
All Rights Reserved.
"""

import os


class Env():
    def __init__(self):
        self.ENGLISH_NUMBER_LENGTH_THRESHOLD = os.environ.get('ENGLISH_NUMBER_LENGTH_THRESHOLD', default=4)
        self.GERMAN_NUMBER_LENGTH_THRESHOLD = os.environ.get('GERMAN_NUMBER_LENGTH_THRESHOLD', default=4)
        self.FRENCH_NUMBER_LENGTH_THRESHOLD = os.environ.get('FRENCH_NUMBER_LENGTH_THRESHOLD', default=4)
        self.ITALIAN_NUMBER_LENGTH_THRESHOLD = os.environ.get('ITALIAN_NUMBER_LENGTH_THRESHOLD', default=4)


env = Env()
