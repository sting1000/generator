"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
from plato_ai_asr_preprocessor.transcription_utils.constants import ALLOWED_CHARSET


# if we encounter a non-supported character, we drop the entire utterance
def process_foreign_chars(token_list: []) -> []:
    for token in token_list:
        if not is_valid_charset(token):
            return ['']  # drop the utterance
    return token_list  # otherwise, return the utterance as is


def normalise_spaces(token_list: []):
    text = ' '.join(token_list)
    return ' '.join(text.split())


def is_valid_charset(text: str) -> bool:
    text_chars = set(list(text.lower()))
    return len(text_chars - ALLOWED_CHARSET) == 0
