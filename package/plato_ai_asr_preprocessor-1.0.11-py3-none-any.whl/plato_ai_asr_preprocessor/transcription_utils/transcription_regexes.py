"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
import re

# times are of the form 10:30 with a colon
regexp_time = re.compile(r'(?P<hour>\b[0-9]{1,2})[:](?P<minute>[0-9]{2}\b)')
# short dates are something like 25.12.2010
regexp_short_date = re.compile(r'(?P<day>\b[0-9]{1,2})(?P<delimeter>[./])'
                               r'(?P<month>[0-9]{1,2})(?P=delimeter)(?P<year>([0-9]{4}|[0-9]{2})\b)')
# really short dates are something like 25.12
regexp_short_short_date = re.compile(r'(?P<day>\b[0-9]{1,2})[./-](?P<month>[0-9]{1,2})\b')
# dates are something like 25 december 2010
regexp_date_string = r'\b(?P<day>[0-9]{1,2})\b( )+\b(?P<month>(' \
                     r'jan(?:uar)?|' \
                     r'jan(?:uary)?|' \
                     r'jan(?:vier)?|' \
                     r'gen(?:naio)?|' \
                     r'feb(?:ruar)?|' \
                     r'feb(?:ruary)?|' \
                     r'fev(?:rier)?|' \
                     r'feb(?:braio)?|' \
                     r'm(ä|ae)r(?:z)?|' \
                     r'mar(?:s)?|' \
                     r'mar(?:ch)?|' \
                     r'mar(?:zo)?|' \
                     r'apr(?:il)?|' \
                     r'avr(?:il)?|' \
                     r'apr(?:ile)?|' \
                     r'mai|' \
                     r'may|' \
                     r'mag(?:gio)?|' \
                     r'jun(?:i)?|' \
                     r'jun(?:e)?|' \
                     r'juin?|' \
                     r'gui(?:gno)?|' \
                     r'jul(?:i)?|' \
                     r'jul(?:y)?|' \
                     r'jui(?:llet)?|' \
                     r'lug(?:lio)?|' \
                     r'aug(?:ust)?|' \
                     r'ao(u|û)t?|' \
                     r'ago(?:sto)?|' \
                     r'sep(?:temb)(er|re)?|' \
                     r'set(?:tembre)?|' \
                     r'okt(?:ober)?|' \
                     r'oct(?:ob(er|re))?|' \
                     r'ott(?:obre)?|' \
                     r'nov(?:emb(er|re))?|' \
                     r'dec(?:emb(er|re))?|' \
                     r'dic(?:emb(er|re))?|' \
                     r'dez(?:ember)))'\
                     r'\b( )+\b(?P<year>[0-9]{2,4})?'
regexp_date = re.compile(regexp_date_string, re.IGNORECASE)
# annotations are added by hand during the transcription process to indicate audio events like silences e.g. [sil]
regexp_protect_annotations = re.compile(r'[\[](?P<annotation>[a-zA-ZäöüÄÖÜéÉàèÀÈâêîôûÂÊÎÔÛïÏçÇ-]+?)[\]](?P<rest>'
                                        + '[a-zA-ZäöüÄÖÜéÉàèÀÈâêîôûÂÊÎÔÛïÏçÇ\[\]-]*)')
# decimals are indicated by periods or commas between numbers
regexp_decimal_number = re.compile(r'(?P<dec>(?P<whole>[0-9]+)[,.](?P<part>[0-9]+))')
# we look for English Pounds (£) or Dollars ($) or Euros (€) either before (pre) or after (post) the numbers
regexp_pre_currency = re.compile(r'(?P<currency>[£$€])( ){0,2}(?P<whole>[0-9]+)([.,](?P<part>[0-9]{2}))*')
regexp_post_currency = re.compile(r'(?P<whole>[0-9]+)([.,](?P<part>[0-9]{2}))*( ){0,2}(?P<currency>[£$€])')
# hesitations in speaking are indicated with hyphens e.g. foot- football or foot- -ball
regexp_hesitation_merge = re.compile(r'\w+(?P<hesitation>-\s-)(?=\w+)')
regexp_hesitation_remove = re.compile(r'\w+-\s')
# acronyms are words like BBC or NATO
regexp_acronyms = re.compile(r'(?P<prefix>[a-zäöüéàèâêîôûïç]+)?(?P<acronym>[A-ZÄÖÜÉÀÈÂÊÎÔÛÏÇ]{2,})(?P<suffix>'
                             + '[a-zäöüéàèâêîôûïçA-ZÄÖÜÉÀÈÂÊÎÔÛÏÇ-]+)?')
