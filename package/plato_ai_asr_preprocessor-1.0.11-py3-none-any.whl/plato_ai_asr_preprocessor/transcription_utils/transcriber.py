"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
from abc import abstractmethod, ABC


class Transcriber (ABC):

    CURRENCY_WORDS = {}

    MONTH = {}

    SPOKEN_SYMBOLS_MAP = {}

    DECIMAL_SEPARATOR = ''

    DECIMAL_REGEX = None

    @classmethod
    @abstractmethod
    def say_money(cls, whole: str, part: str, currency_symbol: str) -> str:
        pass

    @classmethod
    @abstractmethod
    def say_time(cls, hour: str, minute: str) -> str:
        pass

    @classmethod
    @abstractmethod
    def say_date(cls, day: str, month: str, year: str = None) -> str:
        pass

    @staticmethod
    @abstractmethod
    def read_out_number_string(input: str) -> str:
        pass

    @classmethod
    @abstractmethod
    def replace_num_with_words(cls, input: str) -> str:
        pass

    @classmethod
    @abstractmethod
    def replace_num_with_ordinal_words(cls, input: str) -> str:
        pass

    @classmethod
    @abstractmethod
    def get_threshold(cls) -> int:
        pass

    @classmethod
    @abstractmethod
    def set_threshold(cls, new_value: int):
        pass
