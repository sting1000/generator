"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
from num2words import num2words
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_decimal_number
from plato_ai_asr_preprocessor.transcription_utils.transcriber import Transcriber
from plato_ai_asr_preprocessor.transcription_utils.env import env


class ItalianTranscriber (Transcriber):

    CENTURY_WORD = ' cento '

    try:
        NUMBER_LENGTH_THRESHOLD = int(env.ITALIAN_NUMBER_LENGTH_THRESHOLD)
    except ValueError:
        raise ValueError(f'Cannot convert ITALIAN_NUMBER_LENGTH_THRESHOLD '
                         f'env parameter with value {env.ITALIAN_NUMBER_LENGTH_THRESHOLD} to integer')

    HOUR_WORD = ''
    HOURS_WORD = ''
    HOUR_TO_MINUTE_CONNECTOR = ' e '

    DECIMAL_SEPARATOR = ' punto '
    DECIMAL_REGEX = regexp_decimal_number

    CURRENCY_WORDS = {
        '£': (' sterlina ', ' sterline ', ' penny '),
        '€': (' euro ', ' euri ', ' centesimi '),
        '$': (' dollaro ', ' dollari ', ' centesimi ')
    }

    MONTH = {1: 'gennaio',
             2: 'febbraio',
             3: 'marzo',
             4: 'aprile',
             5: 'maggio',
             6: 'giugno',
             7: 'luglio',
             8: 'agosto',
             9: 'settembre',
             10: 'ottobre',
             11: 'novembre',
             12: 'dicembre'
             }

    SPOKEN_SYMBOLS_MAP = {
        '+': ' più ',
        '%': ' percento ',
        '&': ' e '
    }

    @classmethod
    def replace_num_with_words(cls, input: str) -> str:
        if cls.is_text_length_above_threshold(input):
            return cls.read_out_number_string(input)
        text = num2words(int(input), lang='it')
        text = ' '.join(text.split())
        return text

    @classmethod
    def replace_num_with_ordinal_words(cls, input: str) -> str:
        if cls.is_text_length_above_threshold(input):
            return cls.read_out_number_string(input)
        text = num2words(int(input), ordinal=True, lang='it')
        text = ' '.join(text.split())
        return text

    @classmethod
    def say_money(cls, whole: str, part: str, currency_symbol: str) -> str:
        currency_word = cls.CURRENCY_WORDS[currency_symbol]
        whole_words = cls.replace_num_with_words(whole)
        if int(whole) == 1:
            currency = currency_word[0]
        else:
            currency = currency_word[1]

        if part and len(part) > 0:
            if int(whole) == 0:
                money_string = cls.replace_num_with_words(part) + currency_word[2]
            else:
                money_string = whole_words + currency + cls.replace_num_with_words(part) + currency_word[2]
        else:
            money_string = whole_words + currency
        return money_string

    @classmethod
    # this is the most basic implementation possible
    def say_time(cls, hour: str, minute: str) -> str:
        hour = cls.replace_num_with_words(hour)
        if hour == 'uno':
            hour = 'una'
            time_string = 'la ' + hour + cls.HOUR_WORD
        else:
            time_string = 'le ' + hour + cls.HOURS_WORD

        if int(minute) != 0:
            time_string += cls.HOUR_TO_MINUTE_CONNECTOR + cls.replace_num_with_words(minute)

        return time_string

    @classmethod
    def say_date(cls, day: str, month: str, year: str = None) -> str:
        if year:
            date_string = cls.replace_num_with_words(day) + ' ' + month + ' ' + cls.replace_num_with_words(year)
        else:
            date_string = cls.replace_num_with_words(day) + ' ' + month + ' '
        return date_string

    @staticmethod
    def read_out_number_string(input: str) -> str:
        text = ' '.join([num2words(int(s), lang='it') for s in input])
        return text

    @classmethod
    def is_text_length_above_threshold(cls, text: str):
        return len(text) > cls.NUMBER_LENGTH_THRESHOLD

    @classmethod
    def get_threshold(cls):
        return cls.NUMBER_LENGTH_THRESHOLD

    @classmethod
    def set_threshold(cls, new_value: int):
        cls.NUMBER_LENGTH_THRESHOLD = new_value
