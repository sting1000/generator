"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
import re
import regex
from typing import Dict

from plato_ai_asr_preprocessor.transcription_utils.constants import ALLOWED_LANGUAGES, ALLOWED_CHARLIST
from plato_ai_asr_preprocessor.transcription_utils.punctuation_mapper import replace_punctuation
from plato_ai_asr_preprocessor.transcription_utils.punctuation_mapper import PunctuationMode
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_acronyms
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_date
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_hesitation_merge
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_hesitation_remove
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_post_currency
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_pre_currency
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_protect_annotations
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_short_date
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_short_short_date
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_time
from plato_ai_asr_preprocessor.transcription_utils.transcriber import Transcriber
from plato_ai_asr_preprocessor.transcription_utils.english_transcriber import EnglishTranscriber
from plato_ai_asr_preprocessor.transcription_utils.french_transcriber import FrenchTranscriber
from plato_ai_asr_preprocessor.transcription_utils.german_transcriber import GermanTranscriber
from plato_ai_asr_preprocessor.transcription_utils.italian_transcriber import ItalianTranscriber
from plato_ai_asr_preprocessor.transcription_utils.transcription_functions import process_foreign_chars
from plato_ai_asr_preprocessor.transcription_utils.transcription_functions import normalise_spaces


english_transcriber = EnglishTranscriber()
german_transcriber = GermanTranscriber()
french_transcriber = FrenchTranscriber()
italian_transcriber = ItalianTranscriber()


def apply_cleanup(text: str, language: str, configuration: Dict, abbreviation_map: Dict):
    """
    The central entry function that takes text and replaces numbers with words, plus some cleaner specific changes
    :param text: The text to be cleaned
    :param language: The language of the text
    :param configuration: The cleaner configuration - whether to remove hashtags, annotations etc
    :param abbreviation_map: The language specific abbreviations like mr. -> mister
    :return: The cleaned text plus a list of capital acronyms like BBC found in the text
    """
    transcriber = get_transcriber(language)

    # replace dates times etc
    text = perform_regex_replacements(text, transcriber)

    # replace punctuation, abbreviations, spoken symbols
    text = perform_direct_text_replacements(text, language, abbreviation_map, transcriber)

    # based on the cleaner config, perform (or don't) certain text changes e.g. remove hashtag symbols '#'
    text, capital_words = perform_cleaner_specifics(text, configuration)

    return text, capital_words


def perform_direct_text_replacements(text: str, language: str, abbreviation_map: Dict, transcriber: Transcriber) -> str:
    """
    Remove certain punctuation symbols and replace abbreviations with their full equivalent
    :param text: the input text
    :param language: one of the allowed languages
    :param abbreviation_map: language specific sets of common abbreviations like mr. -> mister
    :param transcriber: language specific class for dates, times etc
    :return: the modified text
    """
    # replace abbreviations like mr. with their long version mister
    text = replace_abbreviations(text, language, abbreviation_map)

    # replace spoken symbols like + or &
    text = replace_spoken_symbols(text, transcriber)

    # remove all irrelevant punctuation symbols
    text = replace_punctuation(text, PunctuationMode.UNUSED)

    return text


def perform_regex_replacements(text: str, transcriber: Transcriber) -> str:
    """
    Using regexes, search through the text for replaceable (i.e. replace with words) items like dates times money etc
    :param text: the input text
    :param transcriber: the language specific object that encodes differences in saying times dates etc
    :return: the text with any discovered items replaced with words
    """
    # replace money amounts
    text = replace_pre_money_matches(text, transcriber)
    text = replace_post_money_matches(text, transcriber)
    # replace dates and times
    text = replace_long_date_matches(text, transcriber)
    text = replace_colon_time_matches(text, transcriber)
    text = replace_short_date_matches(text, transcriber)
    text = replace_really_short_date_matches(text, transcriber)
    # replace decimals and remaining numbers
    text = replace_decimal_numbers(text, transcriber)
    # lastly, replace all remaining numbers
    text = replace_number_matches(text, transcriber)
    # clean apostrophes that are not part of a word (like don't)
    text = clean_apostrophes(text)

    return text


# example: 'welcome to swisscom mr. president' transformed to 'welcome to swisscom mister president'
def replace_abbreviations(text: str, language: str, abbreviation_map: Dict) -> str:
    abbreviations = abbreviation_map[language]
    words = text.split()
    words_after_replacement = [abbreviations[word.lower()] if word.lower() in abbreviations.keys()
                               else word for word in words]
    return ' '.join(words_after_replacement)


def perform_cleaner_specifics(text: str, configuration: Dict):
    """
    Depending on the so-called 'cleaner configuration' perform certain textual manipulations like removing hashtags,
    or removing annotations added by the person transcribing the audio like [sil] (silence)
    :param text: the text to be changed
    :param configuration: describes the required cleaner configuration
    :return: the altered text, plus a list of any acronyms found in the text
    """

    # hesitations like 'foot- football' or 'foot- -ball'
    if configuration['process-hesitations']:
        text = process_hesitations(text)

    annotations_iter = regexp_protect_annotations.finditer(text)
    for find in annotations_iter:
        annotation = find.group('annotation')
        if configuration['process-annotations']:
            text = text.replace('[' + annotation + ']', '')
    text = text.replace('[]', '')

    capital_words = []  # list of acronyms found

    list_words = text.split()
    list_out = []

    # if required, remove any words that don't use european characters
    if configuration['remove-chars']:
        list_words = process_foreign_chars(list_words)

    for word in list_words:

        if not configuration['process-hashtags']:
            if re.match(r'[#][' + ALLOWED_CHARLIST + ']+', word):
                text_result = perform_cleaner_specifics(word[1:], configuration)
                text_result_tokens = text_result[0].split()
                for token in text_result_tokens:
                    list_out.append('#%s' % token)
                for token in text_result[1]:
                    capital_words.append('#%s' % token)
                continue

        if configuration['acronym-method'] == 'split':
            acronym_match = regexp_acronyms.match(word)
            if acronym_match:
                prefix = acronym_match.group('prefix')
                acronym = acronym_match.group('acronym')
                suffix = acronym_match.group('suffix')

                capital_words.append(acronym.strip())
                list_out.append(replace_punctuation(prefix.lower(), PunctuationMode.FULL) if prefix else '')
                list_out.append(acronym)
                list_out.append(replace_punctuation(suffix.lower(), PunctuationMode.FULL) if suffix else '')
                continue
        elif configuration['acronym-method'] == 'spoken':
            acronym_match = regexp_acronyms.match(word)
            if acronym_match:
                prefix = acronym_match.group('prefix')
                acronym = acronym_match.group('acronym')
                suffix = acronym_match.group('suffix')

                if not re.search('[AEIOUÄÖÜÉÀÈÂÊÎÔÛÏ]', acronym):
                    acronym = ' '.join(acronym[i:i+1] for i in range(0, len(acronym)))

                capital_words.append(acronym.strip())
                list_out.append(replace_punctuation(prefix.lower(), PunctuationMode.FULL) if prefix else '')
                list_out.append(acronym)
                list_out.append(replace_punctuation(suffix.lower(), PunctuationMode.FULL) if suffix else '')
                continue

        annotations_match = regexp_protect_annotations.match(word)
        if annotations_match:
            if not configuration['process-annotations']:
                annotation = annotations_match.group('annotation')
                rest = annotations_match.group('rest')
                word = '[' + annotation + ']'
                if len(rest) > 0:
                    result = perform_cleaner_specifics(rest, configuration)
                    result_text = result[0]
                    word += result_text
                    if len(result[1]) > 0:
                        capital_words.extend(result[1])
                list_out.append(word)
                continue
            else:
                annotation = annotations_match.group('annotation')
                word = word.replace('[' + annotation + ']', '')
                list_out.append(word)
                continue

        list_out.append(replace_punctuation(word.lower(), PunctuationMode.FULL))

    text = normalise_spaces(list_out)

    return text, capital_words


# example: 'i like to watch foot- football' is transformed to 'i like to watch football'
# example: 'i like to watch foot- -ball' is transformed to 'i like to watch football'
def process_hesitations(text: str) -> str:
    match_hesitation = regexp_hesitation_merge.search(text)
    while match_hesitation:
        hesitation_match = match_hesitation.group('hesitation')
        text = re.sub(hesitation_match, '', text)
        match_hesitation = regexp_hesitation_merge.search(text)

    text = re.sub(regexp_hesitation_remove, '', text)

    return text


# example: 'pi is 3.14159' is transformed to 'pi is three point one four one five nine'
def replace_decimal_numbers(text: str, transcriber: Transcriber) -> str:
    decimal_regex = transcriber.DECIMAL_REGEX
    decimal_separator = transcriber.DECIMAL_SEPARATOR

    match_decimal = decimal_regex.search(text)
    while match_decimal:
        # entire_number = match_decimal.group('dec')
        whole_number_part = match_decimal.group('whole')
        fractional_part = match_decimal.group('part')
        fractional_as_words = ' '.join([transcriber.replace_num_with_words(s) for s in fractional_part])
        if is_text_length_above_threshold(whole_number_part, transcriber):
            decimal_in_words = transcriber.read_out_number_string(whole_number_part) \
                + decimal_separator + fractional_as_words
        else:
            decimal_in_words = transcriber.replace_num_with_words(whole_number_part) \
                               + decimal_separator + fractional_as_words
        text = put_string_into_text(text, decimal_in_words + ' ', match_decimal.span())
        match_decimal = decimal_regex.search(text)
    return text


def is_text_length_above_threshold(text: str, transcriber: Transcriber):
    return len(text) > transcriber.get_threshold()


def find_all_caps(text: str) -> []:
    all_capitals = r'\b([[:upper:]]{2,})\b'
    text_list = regex.findall(all_capitals, text)
    return text_list


def get_transcriber(language: str):
    if language not in ALLOWED_LANGUAGES:
        return english_transcriber
    return {
        'de': german_transcriber,
        'en': english_transcriber,
        'fr': french_transcriber,
        'it': italian_transcriber
    }.get(language)


# example: 'my birthday is 06.06.1975' transformed to 'my birthday is sixth june nineteen seventy five'
def replace_short_date_matches(text: str, transcriber: Transcriber) -> str:
    match_date = regexp_short_date.search(text)
    while match_date:
        day = match_date.group('day')
        month = match_date.group('month')
        year = match_date.group('year')
        if 1 <= int(day) <= 31 and 1 <= int(month) <= 12:
            month = transcriber.MONTH.get(int(month), 'UNKNOWN_MONTH')
            date_string = transcriber.say_date(day, month, year)
            text = put_string_into_text(text, date_string, match_date.span())
        elif 1 <= int(month) <= 31 and 1 <= int(day) <= 12:
            month, day = day, month  # american style dates
            month = transcriber.MONTH.get(int(month), 'UNKNOWN_MONTH')
            date_string = transcriber.say_date(day, month, year)
            text = put_string_into_text(text, date_string, match_date.span())
        match_date = regexp_short_date.search(text, (match_date.span())[1])
    return text


# example: 'my birthday is 06.06' transformed to 'my birthday is sixth june'
def replace_really_short_date_matches(text: str, transcriber: Transcriber) -> str:
    match_date = regexp_short_short_date.search(text)
    while match_date:
        day = match_date.group('day')
        month = match_date.group('month')
        if 1 <= int(day) <= 31 and 1 <= int(month) <= 12:
            month = transcriber.MONTH.get(int(month), 'UNKNOWN_MONTH')
            date_string = transcriber.say_date(day, month)
            text = put_string_into_text(text, date_string, match_date.span())
        elif 1 <= int(month) <= 31 and 1 <= int(day) <= 12:
            month, day = day, month  # american style dates
            month = transcriber.MONTH.get(int(month), 'UNKNOWN_MONTH')
            date_string = transcriber.say_date(day, month)
            text = put_string_into_text(text, date_string, match_date.span())
        match_date = regexp_short_short_date.search(text, (match_date.span())[1])
    return text


# example: 'my birthday is 06 June 1975' transformed to 'my birthday is sixth june nineteen seventy five'
def replace_long_date_matches(text: str, transcriber: Transcriber) -> str:
    match_date = regexp_date.search(text)
    while match_date:
        day = match_date.group('day')
        month = match_date.group('month')
        year = match_date.group('year')
        date_string = transcriber.say_date(day, month, year)
        text = put_string_into_text(text, date_string, match_date.span())
        match_date = regexp_date.search(text)
    return text


# example: 'give me $5.20' transformed to 'give me five dollars twenty cents'
def replace_pre_money_matches(text: str, transcriber: Transcriber) -> str:

    match_money = regexp_pre_currency.search(text)
    while match_money:
        whole = match_money.group('whole')
        part = match_money.group('part')
        currency_symbol = match_money.group('currency')
        money_string = transcriber.say_money(whole, part, currency_symbol)
        text = put_string_into_text(text, money_string, match_money.span())
        match_money = regexp_pre_currency.search(text)
    return text


# example: 'give me 5.20$' transformed to 'give me five dollars twenty cents'
def replace_post_money_matches(text: str, transcriber: Transcriber) -> str:

    match_money = regexp_post_currency.search(text)
    while match_money:
        whole = match_money.group('whole')
        part = match_money.group('part')
        currency_symbol = match_money.group('currency')
        money_string = transcriber.say_money(whole, part, currency_symbol)
        text = put_string_into_text(text, money_string, match_money.span())
        match_money = regexp_post_currency.search(text)
    return text


# example: 'the game starts at 10:30' transformed to 'the game starts at ten thirty'
def replace_colon_time_matches(text: str, transcriber: Transcriber) -> str:
    match_time = regexp_time.search(text)
    while match_time:
        hour = match_time.group('hour')
        minute = match_time.group('minute')
        time_string = transcriber.say_time(hour, minute)
        text = put_string_into_text(text, time_string, match_time.span())
        match_time = regexp_time.search(text)
    return text


# example: 'there are 3 countries in Great Britain' transformed to 'there are three countries in Great Britain'
def replace_number_matches(text: str, transcriber: Transcriber) -> str:
    regexp_digit = re.compile(r'(?P<number>[0-9]+)')
    match_digit = regexp_digit.search(text)
    while match_digit:
        number_match = match_digit.group('number')
        if number_match[0] == '0' or is_text_length_above_threshold(number_match, transcriber):
            number_string = transcriber.read_out_number_string(number_match)
            text = put_string_into_text(text, ' ' + number_string + ' ', match_digit.span())
        else:
            number_string = transcriber.replace_num_with_words(number_match)
            text = put_string_into_text(text, ' ' + number_string + ' ', match_digit.span())
        match_digit = regexp_digit.search(text)
    return text


# example:
# ' apostrophes in a word shouldn't be removed, only ' or 'beginning or end' of word or surrounded by .\'.non word char
# converted to:
# apostrophes in a word shouldn't be removed, only or beginning or end of word or surrounded by non word char
def clean_apostrophes(text: str) -> str:
    regexp_non_word_apostrophe = re.compile(r'\W+\'|\'\W+|^\'|\'$')
    return regexp_non_word_apostrophe.sub(' ', text)


def put_string_into_text(text: str, insert_string: str, span: ()) -> str:
    start, end = span
    if start < 0 or end < 0 or end < start or start > len(text)-1 or end > len(text):
        return ''
    start_string = text[:start]
    end_string = text[end:]
    return start_string + insert_string + end_string


# example: 'hello & welcome' transformed to 'hello and welcome'
def replace_spoken_symbols(text: str, transcriber: Transcriber) -> str:
    for spoken_symbol in transcriber.SPOKEN_SYMBOLS_MAP.keys():
        text = text.replace(spoken_symbol, transcriber.SPOKEN_SYMBOLS_MAP[spoken_symbol])
    return text
