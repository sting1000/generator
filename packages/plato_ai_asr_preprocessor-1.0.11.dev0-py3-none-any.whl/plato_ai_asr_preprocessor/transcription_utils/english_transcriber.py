"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""
from num2words import num2words
from plato_ai_asr_preprocessor.transcription_utils.transcription_regexes import regexp_decimal_number
from plato_ai_asr_preprocessor.transcription_utils.transcriber import Transcriber
from plato_ai_asr_preprocessor.transcription_utils.env import env


class EnglishTranscriber (Transcriber):

    CENTURY_WORD = ' '

    try:
        NUMBER_LENGTH_THRESHOLD = int(env.ENGLISH_NUMBER_LENGTH_THRESHOLD)
    except ValueError:
        raise ValueError(f'Cannot convert ENGLISH_NUMBER_LENGTH_THRESHOLD '
                         f'env parameter with value {env.ENGLISH_NUMBER_LENGTH_THRESHOLD} to integer')

    HOUR_WORD = ' o\'clock'
    HOUR_TO_MINUTE_CONNECTOR = ' '

    DECIMAL_SEPARATOR = ' point '
    DECIMAL_REGEX = regexp_decimal_number

    CURRENCY_WORDS = {
        '£': (' pound ', ' pounds ', ' pence '),
        '€': (' euro ', ' euros ', ' cents '),
        '$': (' dollar ', ' dollars ', ' cents ')
    }

    MONTH = {1: 'january',
             2: 'february',
             3: 'march',
             4: 'april',
             5: 'may',
             6: 'june',
             7: 'july',
             8: 'august',
             9: 'september',
             10: 'october',
             11: 'november',
             12: 'december'
             }

    SPOKEN_SYMBOLS_MAP = {
            '+': ' plus ',
            '%': ' percent ',
            '&': ' and '
    }

    @classmethod
    def say_date(cls, day: str, month: str, year: str = None) -> str:
        if year and len(year) == 4:
            century = year[:2]
            year = year[2:]
            date_string = cls.replace_num_with_ordinal_words(day) + ' ' + month + ' ' \
                + cls.replace_num_with_words(century) + cls.CENTURY_WORD \
                + cls.replace_num_with_words(year, False)
        elif year and len(year) == 2:
            date_string = cls.replace_num_with_ordinal_words(day) + ' ' + month + ' ' \
                + cls.replace_num_with_words(year, False)
        else:
            date_string = cls.replace_num_with_ordinal_words(day) + ' ' + month + ' '
        return date_string

    @classmethod
    def say_money(cls, whole: str, part: str, currency_symbol: str) -> str:
        currency_word = cls.CURRENCY_WORDS[currency_symbol]
        whole_words = cls.replace_num_with_words(whole)
        if int(whole) == 1:
            currency = currency_word[0]
        else:
            currency = currency_word[1]
        if part and len(part) > 0:
            if int(whole) == 0:
                money_string = cls.replace_num_with_words(part, True) + currency_word[2]
            else:
                money_string = whole_words + currency + cls.replace_num_with_words(part, True) + currency_word[2]
        else:
            money_string = whole_words + currency
        return money_string

    @classmethod
    def say_time(cls, hour: str, minute: str) -> str:
        if int(hour) == 0:
            if int(minute) == 0:
                time_string = ' midnight '
            else:
                time_string = cls.replace_num_with_words(minute, True) + ' minutes past midnight'
        else:
            if int(minute) == 0:
                time_string = cls.replace_num_with_words(hour, True) + cls.HOUR_WORD
            else:
                time_string = cls.replace_num_with_words(hour, True) + cls.HOUR_TO_MINUTE_CONNECTOR \
                              + cls.replace_num_with_words(minute, False)
        return time_string

    @classmethod
    def replace_num_with_words(cls, input: str, oh_suppression: bool = True) -> str:
        if cls.is_text_length_above_threshold(input):
            return cls.read_out_number_string(input)
        if oh_suppression:
            text = num2words(int(input), lang='en')
        else:
            oh_flag = False
            if len(input) == 0:
                return ' '
            oh_prefix = ''
            while len(input) > 1 and input[0] == '0':
                oh_flag = True
                oh_prefix += ' oh '
                input = input[1:]
            if oh_flag and input == '0':
                text = oh_prefix + ' oh '
            else:
                text = oh_prefix + num2words(int(input), lang='en')
        text = text.replace('-', ' ')
        text = ' '.join(text.split())
        return text

    @classmethod
    def replace_num_with_ordinal_words(cls, input: str, oh_suppression: bool = True) -> str:
        if cls.is_text_length_above_threshold(input):
            return cls.read_out_number_string(input)
        if oh_suppression:
            text = num2words(int(input), ordinal=True, lang='en')
        else:
            oh_flag = False
            if len(input) == 0:
                return ' '
            oh_prefix = ''
            while len(input) > 1 and input[0] == '0':
                oh_flag = True
                oh_prefix += ' oh '
                input = input[1:]
            if oh_flag and input == '0':
                text = oh_prefix + ' ohth '
            else:
                text = oh_prefix + num2words(int(input), ordinal=True, lang='en')
        text = text.replace('-', ' ')
        text = ' '.join(text.split())
        return text

    @staticmethod
    def read_out_number_string(input: str) -> str:
        text = ' '.join([num2words(int(s), lang='en') for s in input])
        return text

    @classmethod
    def is_text_length_above_threshold(cls, text: str):
        return len(text) > cls.NUMBER_LENGTH_THRESHOLD

    @classmethod
    def get_threshold(cls):
        return cls.NUMBER_LENGTH_THRESHOLD

    @classmethod
    def set_threshold(cls, new_value: int):
        cls.NUMBER_LENGTH_THRESHOLD = new_value
