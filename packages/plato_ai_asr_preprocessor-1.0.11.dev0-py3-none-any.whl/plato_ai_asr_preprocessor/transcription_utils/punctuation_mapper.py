"""
(c) Copyright 2019 Swisscom AG
All Rights Reserved.
"""

from plato_ai_asr_preprocessor.transcription_utils.constants import UNUSED_PUNCTUATION_MAP
from plato_ai_asr_preprocessor.transcription_utils.constants import PUNCTUATION_MAP
from enum import Enum


class PunctuationMode(Enum):
    UNUSED = 1
    FULL = 2


def replace_punctuation(text: str, mode: PunctuationMode) -> str:
    if mode == PunctuationMode.UNUSED:
        MAP = UNUSED_PUNCTUATION_MAP
    else:
        MAP = PUNCTUATION_MAP
    for punctuation_symbol, replacement in MAP.items():
        text = text.replace(punctuation_symbol, replacement)
    return text
